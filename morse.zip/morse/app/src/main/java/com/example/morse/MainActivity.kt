package com.example.morse

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID
import kotlin.concurrent.thread


//  MÓDULO DE SEGURIDAD ISO/IEC 27400

object IoTSecurityManager {
    fun getEncryptedPrefs(context: Context) = EncryptedSharedPreferences.create(
        context,
        "secure_iot_morse_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun sanitizeInput(input: String): String {
        return input.uppercase().filter { it in 'A'..'Z' || it in '0'..'9' || it == ' ' }
    }

    fun hashPassword(pass: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pass.toByteArray(StandardCharsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}


// MÓDULO DE CONECTIVIDAD BLUETOOTH RFCOMM / SPP

@SuppressLint("MissingPermission")
class BluetoothIoTManager(
    private val onDataReceived: (String) -> Unit,
    private val onConnectionChanged: (Boolean) -> Unit
) {
    private var socket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null
    private var inputStream: InputStream? = null
    private var isListening = false
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun connectToDevice(device: BluetoothDevice) {
        thread {
            try {
                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket?.connect()
                outputStream = socket?.outputStream
                inputStream = socket?.inputStream
                isListening = true
                startListening()
                onConnectionChanged(true)
            } catch (e: Exception) {
                e.printStackTrace()
                disconnect()
            }
        }
    }

    fun sendSecureData(text: String) {
        thread {
            try {
                val sanitized = IoTSecurityManager.sanitizeInput(text)
                if (sanitized.isNotEmpty()) {
                    val payload = sanitized + "\n"
                    outputStream?.write(payload.toByteArray(StandardCharsets.UTF_8))
                    outputStream?.flush()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun startListening() {
        thread {
            val buffer = ByteArray(1024)
            while (isListening) {
                try {
                    val bytesRead = inputStream?.read(buffer) ?: -1
                    if (bytesRead > 0) {
                        val rawData = String(buffer, 0, bytesRead).trim()
                        if (rawData.isNotEmpty()) {
                            onDataReceived(rawData)
                        }
                    }
                } catch (e: Exception) {
                    isListening = false
                    onConnectionChanged(false)
                    break
                }
            }
        }
    }

    fun disconnect() {
        isListening = false
        try {
            socket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        onConnectionChanged(false)
    }
}


// ACTIVIDAD PRINCIPAL Y NAVEGACION

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppRootNavigator(context = this)
                }
            }
        }
    }
}

@Composable
fun AppRootNavigator(context: Context) {
    var isAuthenticated by remember { mutableStateOf(false) }

    if (!isAuthenticated) {
        LoginScreen(context = context) { isAuthenticated = true }
    } else {
        MonitoringAndActivatorScreen()
    }
}


// PANTALLA DE AUTENTICACIÓN (LOGIN EDUCATIVO)

@Composable
fun LoginScreen(context: Context, onLoginSuccess: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val prefs = remember { IoTSecurityManager.getEncryptedPrefs(context) }

    val defaultUser = "admin"
    val defaultPassHash = IoTSecurityManager.hashPassword("admin123")

    if (prefs.getString("STORED_USER", null) == null) {
        prefs.edit()
            .putString("STORED_USER", defaultUser)
            .putString("STORED_PASS", defaultPassHash)
            .apply()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Aula Interactiva Morse IoT", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Text("ISO/IEC 27400 - Acceso Seguro Estudiante/Docente", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Usuario (admin)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Contraseña (admin123)") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (errorMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(errorMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val savedUser = prefs.getString("STORED_USER", "")
                val savedPassHash = prefs.getString("STORED_PASS", "")
                val inputPassHash = IoTSecurityManager.hashPassword(password)

                if (username.trim() == savedUser && inputPassHash == savedPassHash) {
                    onLoginSuccess()
                } else {
                    errorMessage = "Credenciales incorrectas. Intente nuevamente."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Ingresar al Laboratorio")
        }
    }
}


// PANTALLA DE PRÁCTICA, MONITOREO Y ENVÍO MORSE

@SuppressLint("MissingPermission")
@Composable
fun MonitoringAndActivatorScreen() {
    val context = LocalContext.current
    var messageInput by remember { mutableStateOf("") }
    var isConnected by remember { mutableStateOf(false) }
    var hasPermissions by remember { mutableStateOf(false) }
    val transmissionLogs = remember { mutableStateListOf<String>() }
    var pairedDevices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }

    val bluetoothManagerService = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    val bluetoothAdapter: BluetoothAdapter? = bluetoothManagerService.adapter

    val requiredPermissions = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            )
        } else {
            arrayOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.all { it }
        hasPermissions = granted
        if (granted) {
            pairedDevices = bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
            transmissionLogs.add(0, "[Sistema]: Permisos Bluetooth concedidos.")
        } else {
            transmissionLogs.add(0, "[Error]: Permisos Bluetooth denegados.")
        }
    }

    LaunchedEffect(Unit) {
        val allGranted = requiredPermissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        if (allGranted) {
            hasPermissions = true
            pairedDevices = bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
        } else {
            permissionLauncher.launch(requiredPermissions)
        }
    }

    val bluetoothManager = remember {
        BluetoothIoTManager(
            onDataReceived = { incomingData ->
                transmissionLogs.add(0, "[Nodo → App]: $incomingData")
            },
            onConnectionChanged = { connected ->
                isConnected = connected
                if (connected) {
                    transmissionLogs.add(0, "[Sistema]: Enlace inalámbrico establecido.")
                } else {
                    transmissionLogs.add(0, "[Sistema]: Nodo Morse desconectado.")
                }
            }
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            bluetoothManager.disconnect()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isConnected) Color(0xFFD4EDDA) else Color(0xFFF8D7DA)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isConnected) "Nodo Morse: CONECTADO" else "Nodo Morse: DESCONECTADO",
                    color = if (isConnected) Color(0xFF155724) else Color(0xFF721C24),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                if (isConnected) {
                    Button(
                        onClick = { bluetoothManager.disconnect() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC3545))
                    ) {
                        Text("Desconectar", fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (!isConnected) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Dispositivos Vinculados:", style = MaterialTheme.typography.titleSmall)
                TextButton(onClick = {
                    if (hasPermissions) {
                        pairedDevices = bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
                    } else {
                        permissionLauncher.launch(requiredPermissions)
                    }
                }) {
                    Text("Actualizar")
                }
            }

            if (pairedDevices.isEmpty()) {
                Text(
                    "No se encontraron dispositivos emparejados. Vincula tu módulo HC-05 en ajustes Bluetooth.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .background(Color(0xFFF4F4F4))
                        .padding(4.dp)
                ) {
                    items(pairedDevices) { device ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(device.name ?: "Dispositivo IoT", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                Text(device.address, fontSize = 11.sp, color = Color.Gray)
                            }
                            Button(onClick = {
                                transmissionLogs.add(0, "[Sistema]: Conectando a ${device.name}...")
                                bluetoothManager.connectToDevice(device)
                            }) {
                                Text("Conectar", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("Enviar Ejercicio al Nodo (App → Arduino):", style = MaterialTheme.typography.titleSmall)
        Spacer(modifier = Modifier.height(4.dp))

        OutlinedTextField(
            value = messageInput,
            onValueChange = { messageInput = it },
            label = { Text("Palabra o código a reproducir") },
            placeholder = { Text("Ej: HOLA") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                if (messageInput.isNotBlank()) {
                    val sanitized = IoTSecurityManager.sanitizeInput(messageInput)
                    bluetoothManager.sendSecureData(sanitized)
                    transmissionLogs.add(0, "[App → Nodo]: $sanitized")
                    messageInput = ""
                }
            },
            enabled = isConnected,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Reproducir en Buzzer y LED")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("Consola de Aprendizaje (Tiempo Real):", style = MaterialTheme.typography.titleSmall)
        Spacer(modifier = Modifier.height(4.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF121212))
                .padding(8.dp)
        ) {
            items(transmissionLogs) { log ->
                Text(
                    text = log,
                    color = Color(0xFF00FF66),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp
                )
            }
        }
    }
}